import WebSlides from './modules/webslides';
require('../scss/full.scss');

window.WebSlides = WebSlides;
